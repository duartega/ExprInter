#include <iostream>
#include "SymTab.hpp"


void SymTab::setValueFor(std::string vName, int value) {
    symTab[vName] = TypeDescriptor(value);
}

void SymTab::setValueFor(std::string vName, std::string value) {
    symTab[vName] = TypeDescriptor(value);
}

void SymTab::setValueFor(std::string vName, bool value) {
    symTab[vName] = TypeDescriptor(value);
}

void SymTab::setValueFor(std::string vName, TypeDescriptor value)
{
    symTab[vName] = value;
}

void SymTab::setValueFor(std::string vName, std::vector<TypeDescriptor> value) {
    symTab[vName] = TypeDescriptor(value);
}

bool SymTab::isDefined(std::string vName) {
    return symTab.find(vName) != symTab.end();
}

int SymTab::getIntValueFor(std::string vName) {
    if( ! isDefined(vName)) {
        std::cout << "SymTab::getValueFor: " << vName << " has not been defined.\n";
        exit(1);
    }
    return symTab.find(vName)->second.get_ivalue();
}

std::string SymTab::getStringValueFor(std::string vName) {
    if( ! isDefined(vName)) {
        std::cout << "SymTab::getValueFor: " << vName << " has not been defined.\n";
        exit(1);
    }
    return symTab.find(vName)->second.get_svalue();
}

bool SymTab::getBoolValueFor(std::string vName) {
    if( ! isDefined(vName)) {
        std::cout << "SymTab::getValueFor: " << vName << " has not been defined.\n";
        exit(1);
    }
    return symTab.find(vName)->second.get_bvalue();
}

TypeDescriptor SymTab::getValueFor(std::string vName) {
    if( ! isDefined(vName)) {
        std::cout << "SymTab::getValueFor: " << vName << " has not been defined.\n";
        exit(1);
    }
    return symTab.find(vName)->second;
}